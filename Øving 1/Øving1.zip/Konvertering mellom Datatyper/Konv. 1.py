flyttall = float(input("Skriv inn et flyttall: "))
flyttall1 = float(input("Skriv inn et annet flyttall: "))
flyttall2 = float(input("Skriv inn et siste flyttall: "))

helttall = round(flyttall)
helttall1 = round(flyttall1)
helttall2 = round(flyttall2)


print("Konvertert til et helttall blir det: ", helttall , helttall1 , helttall2)

nyhelt = int(input("Skriv inn ett helttall: "))
nyflyt = float(nyhelt)

print("Konvertert til flyttall blir det: ", nyflyt)




