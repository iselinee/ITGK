"Teori oppgaver"

'a. Hva er Alan Turning kjent for?'
   'Lagde den første modellen for en generell datamaskin, og la grunnlaget for algoritmer og databehandling'

'b. Hva kalles mindre kretskort som plugges inn i hoved(krets-)kortet?'
   'Datterkort'

'c. Hva står CPU for?'
   'Central Processing Unit'

'd. RAM står for random access memory, men hva menes egentlig med random i dette tilfellet?'
   'Fordi ram gir tilgang til lagret data i tilfeldig (random) rekkefølge'