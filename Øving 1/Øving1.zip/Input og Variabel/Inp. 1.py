navn = input ("Hei, hva heter du? ")

print(navn, "- kult navn!")


fag = input ("Favorittfag? ")

print(fag, "- interessant!")