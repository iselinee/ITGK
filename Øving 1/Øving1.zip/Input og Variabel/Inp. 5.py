navn = "Iselin Eng"
alder = "20"

print("Jeg heter",navn, ", og er", alder , "år.")