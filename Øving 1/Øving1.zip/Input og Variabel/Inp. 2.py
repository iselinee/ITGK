navn = input("Navn? ")
print("Hei,", navn)

fag = input("Favorittfag? ")
print(fag, "- interessant!")
print("Ha en fin dag,", navn)
print("- og lykke til med", fag)