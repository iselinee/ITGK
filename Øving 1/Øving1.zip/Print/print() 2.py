print('"Jeg elsker ITGK!" ropte studenten da 1c funket')

'Bruker kommandoen print til å skrive ut kommentaren'
'"Jeg elsker ITGK!" ropte studenten da 1c funktet'