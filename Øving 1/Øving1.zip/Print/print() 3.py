print('Noen barn sto og hang ved lekeplassen.')
print('Diskusjonstemaet deres var noe uventet.')
print("""- Hvorfor heter'e "Python"?""")
print("- Var'e slanger som laget det? - Nei, Guido van Rossum.")
print("""- Likte slanger kanskje da? - Nei, digga "Monty Python""""")
print("- Hva er det? Et fjell?")
print("- Nei, engelsk komigruppe. Begynte i '69.")
print("- Wow! Var'e fremdeles dinosaurer da?")

'Laget nye linjer for hver, fordi jeg ikke har lært hvordan man tar "Enter" i Python..'
'Kopierte bare teksten linje for linje over'