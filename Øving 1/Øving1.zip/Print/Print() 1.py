x = 385180
y = 5.3
print("Norge")
print(" ")
print("Avstand (kv.km): " , x)
print("Folketall ( mill.):" , y)


